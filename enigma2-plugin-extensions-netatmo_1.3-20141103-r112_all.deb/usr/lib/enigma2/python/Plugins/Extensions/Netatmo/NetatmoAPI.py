#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
#  code based on: https://github.com/philippelt/netatmo-api-python
#  great thanks to: philippelt@users.sourceforge.net

from sys import version_info
import json, time

# HTTP libraries depends upon Python 2 or 3
if version_info[0] == 3:
    import urllib.parse, urllib.request
else:
    from urllib import urlencode
    import urllib2

# Common definitions

_BASE_URL = "https://api.netatmo.net/"
_AUTH_REQ = _BASE_URL + "oauth2/token"
_GETUSER_REQ = _BASE_URL + "api/getuser"
_DEVICELIST_REQ = _BASE_URL + "api/devicelist"
_GETMEASURE_REQ = _BASE_URL + "api/getmeasure"

# User-based specs

_CLIENT_ID = "<your client_id>"                         # From Netatmo app registration
_CLIENT_SECRET = "<your client_secret>"                     #   '     '
_USERNAME = "<netatmo username>"
_PASSWORD = "<netatmo user password>"

class ClientAuth:
    "Request authentication and keep access token available through token method. Renew it automatically if necessary"

    def __init__(self, clientId=_CLIENT_ID,
                       clientSecret=_CLIENT_SECRET,
                       username=_USERNAME,
                       password=_PASSWORD):

        postParams = {
                "grant_type" : "password",
                "client_id" : clientId,
                "client_secret" : clientSecret,
                "username" : username,
                "password" : password,
                "scope" : "read_station read_thermostat"
                }
        resp = postRequest(_AUTH_REQ, postParams)

        self._clientId = clientId
        self._clientSecret = clientSecret
        self._accessToken = resp['access_token']
        self.refreshToken = resp['refresh_token']
        self._scope = resp['scope']
        self.expiration = int(resp['expire_in'] + time.time())

    @property
    def accessToken(self):
        "Provide the current or renewed access token"

        if self.expiration < time.time(): # Token should be renewed

            postParams = {
                    "grant_type" : "refresh_token",
                    "refresh_token" : self.refreshToken,
                    "client_id" : self._clientId,
                    "client_secret" : self._clientSecret
                    }
            resp = postRequest(_AUTH_REQ, postParams)

            self._accessToken = resp['access_token']
            self.refreshToken = resp['refresh_token']
            self.expiration = int(resp['expire_in'] + time.time())

        return self._accessToken

class User:
    "Access to user account information"

    def __init__(self, authData):

        postParams = {
                "access_token" : authData.accessToken
                }
        resp = postRequest(_GETUSER_REQ, postParams)
        self.rawData = resp['body']
        self.id = self.rawData['_id']
        if self.rawData.has_key('devices'):
            self.devList = self.rawData['devices']
        else:
            self.devList = self.rawData['friend_devices']
        self.ownerMail = self.rawData['mail']

class DeviceList:
    "Set of stations and modules attached to the user account"
    
    def __init__(self):
        pass

    def request(self, authData):
        self.getAuthToken = authData.accessToken
        postParams = {
                "access_token" : self.getAuthToken,
                "app_type" : "app_station"
                }
        resp = postRequest(_DEVICELIST_REQ, postParams)
        self.raw = resp['body']
    
    def listDevices(self):
        devices = self.raw['devices']
        return devices
    
    def getModule(self, module_id):
        module = next((x for x in self.raw['modules'] if x['_id'] == module_id), None)
        return module
    
    def getModuleData(self, module):
        data = module['dashboard_data']
        return data
    
    def getDeviceData(self, device):
        data = device['dashboard_data']
        return data

def postRequest(url, params):
    if version_info[0] == 3:
        req = urllib.request.Request(url)
        req.add_header("Content-Type", "application/x-www-form-urlencoded;charset=utf-8")
        params = urllib.parse.urlencode(params).encode('utf-8')
        resp = urllib.request.urlopen(req, params).readall().decode("utf-8")
    else:
        params = urlencode(params)
        headers = {"Content-Type" : "application/x-www-form-urlencoded;charset=utf-8"}
        req = urllib2.Request(url=url, data=params, headers=headers)
        resp = urllib2.urlopen(req).read()
    return json.loads(resp)

if __name__ == "__main__":
    from sys import exit, stderr
    if not _CLIENT_ID or not _CLIENT_SECRET or not _USERNAME or not _PASSWORD :
        stderr.write("Missing arguments to check lnetatmo.py")
        exit(1)
    
    authorization = ClientAuth()                # Test authentication method
    user = User(authorization)                  # Test GETUSER
    devList = DeviceList(authorization)         # Test DEVICELIST
    devList.MinMaxTH()                          # Test GETMEASURE
    
    # If we reach this line, all is OK
    exit(0)
