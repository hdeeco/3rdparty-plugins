#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula and JackDaniel (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Components.config import config, ConfigSubsection, ConfigText, ConfigPassword, ConfigYesNo, ConfigInteger
from Plugins.Plugin import PluginDescriptor

config.Netatmo = ConfigSubsection()
config.Netatmo.enabled = ConfigYesNo(True)
config.Netatmo.simulate = ConfigYesNo(False)
config.Netatmo.user = ConfigText("", False)
config.Netatmo.select_last = ConfigYesNo(True)
config.Netatmo.selection_last = ConfigText('["",""]')
config.Netatmo.preferred = ConfigText('["",""]')
config.Netatmo.notifications = ConfigText('{}')
config.Netatmo.password = ConfigPassword("", False)
config.Netatmo.update_interval = ConfigInteger(60, (1, 1440))
config.Netatmo.show_notification = ConfigYesNo(False)
config.Netatmo.indoor_temp_limit = ConfigInteger(24, (1, 50))
config.Netatmo.indoor_humidity_limit = ConfigInteger(50, (0, 100))
config.Netatmo.indoor_pressure_limit = ConfigInteger(1100, (1, 1500))
config.Netatmo.indoor_noise_limit = ConfigInteger(80, (1, 200))
config.Netatmo.indoor_co2_limit = ConfigInteger(1500, (1, 2500))
config.Netatmo.outdoor_temperature_limit = ConfigInteger(24, (1, 50))
config.Netatmo.outdoor_humidity_limit = ConfigInteger(95, (0, 100))
config.Netatmo.outdoor_battery_limit = ConfigInteger(3, (3, 7))
config.Netatmo.show_indoor_temp_limit = ConfigYesNo(False)
config.Netatmo.show_indoor_humidity_limit = ConfigYesNo(False)
config.Netatmo.show_indoor_pressure_limit = ConfigYesNo(False)
config.Netatmo.show_indoor_noise_limit = ConfigYesNo(False)
config.Netatmo.show_indoor_co2_limit = ConfigYesNo(False)
config.Netatmo.show_outdoor_temperature_limit = ConfigYesNo(False)
config.Netatmo.show_outdoor_humidity_limit = ConfigYesNo(False)
config.Netatmo.show_outdoor_battery_limit = ConfigYesNo(False)
config.Netatmo.notifictaion_time = ConfigInteger(20, (3, 60))
config.Netatmo.show_netatmobar = ConfigYesNo(True)
config.Netatmo.show_stationlist = ConfigYesNo(True)

def sessionstart(reason, **kwargs):
    if reason == 0:
        session = kwargs["session"]
        from Netatmo import netatmoUpdater, netatmo
        netatmo.SIMULATE = config.Netatmo.simulate.value
        config.Netatmo.update_interval.addNotifier(netatmoUpdater.updateTimer, True, False)
        from Notification import netatmoNotificationUpdater
        config.Netatmo.update_interval.addNotifier(netatmoNotificationUpdater.updateTimer, True, False)
        from NetatmoBar import initNetatmoBar
        initNetatmoBar()
        
def pluginOpen(session, **kwargs):
    from Netatmo import Netatmo
    session.open(Netatmo)

def pluginSetup(session, **kwargs):
    from NetatmoSetup import NetatmoSetup
    session.open(NetatmoSetup)

def Plugins(**kwargs):
    descriptors = []
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_SESSIONSTART, description=_("Netatmo information"), fnc=sessionstart))
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_EXTENSIONSMENU, description=_("Netatmo information"), icon = "images/g3icon_netatmo.png", fnc=pluginOpen))
    descriptors.append(PluginDescriptor(name=_("Netatmo"), where=PluginDescriptor.WHERE_PLUGINMENU, description=_("Netatmo information"), icon = "images/plugin.png", fnc=pluginOpen))
    return descriptors
