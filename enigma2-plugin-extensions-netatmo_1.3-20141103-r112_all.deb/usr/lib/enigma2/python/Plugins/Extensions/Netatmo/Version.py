#!/usr/bin/python
# -*- coding: utf-8 -*-

__version__ = "1.3"
__date__ = "2014.11.03"
__branch__ = "branches/OE2.2"
__revision__ = "112"
__build_version__ = "2.7.5 (default, May 15 2013, 22:44:16) [MSC v.1500 64 bit (AMD64)]"
__build_platform__ = "win32"
