#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula and JackDaniel (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from timer import eTimer
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ActionMap import ActionMap
from Components.GUIComponent import GUIComponent
from Components.config import config
from enigma import RT_HALIGN_LEFT, gFont, eListbox, eListboxPythonMultiContent
from NetatmoCore import Stations, NetatmoUnit, Sensor
from NetatmoSetup import NetatmoSetup
from Components.Slider import Slider
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from NetatmoLabel import NetatmoLabel

IMAGE_PATH = "Extensions/Netatmo/images/"

netatmo = Stations()

from threading import Thread
class NetatmoUpdateThread(Thread):
    def __init__(self, wait_ms=0, init_on_finished=False):
        Thread.__init__(self)
        self.init_on_finished = init_on_finished
        self.start()

    def run(self):
        try:
            netatmo.update(config.Netatmo.user.value, config.Netatmo.password.value)
            if self.init_on_finished:
                selectPreferred()
        except Exception, e:
            print e

class NetatmoUpdater():
    def __init__(self):
        self.__timer = eTimer()
        self.__timer_conn = self.__timer.timeout.connect(self.update)
        self.init = True
    
    def updateTimer(self, configElement):
        print "[Netatmo] set timer", str(configElement.value)
        self.__timer.start(configElement.value * 1000 * 60, False)
        self.update()
    
    def update(self, async=True):
        if config.Netatmo.enabled.value:
            if async:
                print "[Netatmo] start async update"
                NetatmoUpdateThread(init_on_finished=self.init)
                self.init = False
            else:
                try:
                    print "[Netatmo] start sync update"
                    netatmo.update(config.Netatmo.user.value, config.Netatmo.password.value)
                except:
                    pass
            print "[Netatmo] end update"

netatmoUpdater = NetatmoUpdater()

def selectPreferred():
    station, module = evalConfigValue(config.Netatmo.preferred)
    netatmo.select(station, module)

def evalConfigValue(conf):
    try:
        l = eval(conf.value)
        if isinstance(l, list) and len(l) == 2:
            return l
    except:
        pass
    return ["", ""]


class StationList(GUIComponent):
    def __init__(self):
        GUIComponent.__init__(self)
        self.l = eListboxPythonMultiContent()
        self.l.setBuildFunc(self.buildSelectionListEntry)
        self.l.setFont(0, gFont("Regular", 20))                             
        self.l.setItemHeight(30)
        self.onSelectionChanged = [ ]

    def connectSelChanged(self, fnc):
        if not fnc in self.onSelectionChanged:
            self.onSelectionChanged.append(fnc)

    def disconnectSelChanged(self, fnc):
        if fnc in self.onSelectionChanged:
            self.onSelectionChanged.remove(fnc)

    def selectionChanged(self):
        for x in self.onSelectionChanged:
            x()        

    def buildSelectionListEntry(self, station):
        width = self.l.getItemSize().width()
        res = [ None ]        
        res.append((eListboxPythonMultiContent.TYPE_TEXT, 5, 2, width - 30 , 23, 0, RT_HALIGN_LEFT, station.name.encode('utf8')))
        return res

    GUI_WIDGET = eListbox
    
    def postWidgetCreate(self, instance):
        instance.setContent(self.l)
        self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)

    def preWidgetRemove(self, instance):
        instance.setContent(None)
        self.selectionChanged_conn = None

    def getCurrentIndex(self):
        return self.instance.getCurrentIndex()
    
    def getSelectionIndex(self):
        return self.l.getCurrentSelectionIndex()

    def setList(self, l):
        self.l.setList(l)
        self.__list = l
    
    def getCurrent(self):
        l = self.l.getCurrentSelection()
        return l and l[0]
    
    def moveTo(self, name):
        count = 0
        for x in self.__list:
            if x[0].name == name:
                self.instance.moveSelectionTo(count)
                return x[0]
            count += 1
        return None


class Netatmo(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = "Netatmo_V2"
        self["NetatmoActions"] = ActionMap(["ShortcutActions", "WizardActions", "InfobarEPGActions", "MenuActions"],
        {
            "red": self.close,
            "green": self.updateCallback,
            "yellow": self.selectPreferred,
            "blue": self.savePreferred,
            "back": self.close,
            "menu": self.openMenu,
            #"nextBouquet": self.pageUp,
            #"prevBouquet": self.pageDown,
            "left": self.left,
            "right": self.right,
            "showEventInfo": self.notifications,
        }, -1)
        self.__timer = eTimer()
        self.__timer_conn = self.__timer.timeout.connect(self.updateCallback)
        self["key_red"] = Label(_("Close"))
        self["key_green"] = Label(_("Update"))
        self["key_yellow"] = Label(_("Preferred"))
        self["key_blue"] = Label(_("Save preferred"))
        self["button_red"] = Pixmap()
        self["button_green"] = Pixmap()
        self["button_yellow"] = Pixmap()
        self["button_blue"] = Pixmap()
        self["stations_txt"] = Label()
        self["stations"] = StationList()
        #self["details"] = ScrollLabel()
        self["wifi_pixmap"] = MultiPixmap()
        self["signal_pixmap"] = MultiPixmap()
        self["battery_pixmap"] = MultiPixmap()
        self["co2_pixmap"] = MultiPixmap()
        self["co2_pixmap_module"] = MultiPixmap()
        self["noise_slider"] = Slider(0, 100)
        self.addLabel("last_refresh")
        self.addLabel("indoor.when")
        self.addLabel("indoor.module_name")
        self.addLabel("outdoor.module_name")
        self.addWidgets("Place", _("Place"), "place.area")
        self.addWidgets("Firmware station", _("Firmware"), "station.firmware")
        self.addWidgets("Firmware module", _("Firmware"), "outdoor.firmware")
        self.addWidgets("Temperature outdoor", _("Temperature"), "outdoor.temperature")
        self.addWidgets("Temperature indoor", _("Temperature"), "indoor.temperature")
        self.addWidgets("Humidity indoor", _("Humidity"), "indoor.humidity")
        self.addWidgets("Humidity outdoor", _("Humidity"), "outdoor.humidity")
        self.addWidgets("Pressure", _("Pressure"), "indoor.pressure")
        self.addWidgets("CO2 indoor", _("CO2"), "indoor.co2")
        self.addWidgets("CO2 outdoor", _("CO2"), "outdoor.co2")
        self.addWidgets("Battery", _("Battery"), "outdoor.battery")
        self.addWidgets("Noise", _("Noise"), "indoor.noise")
        self.addWidgets("WiFi strength", _("WiFi strength"), "station.wifi_status")
        self.addWidgets("RF strength", _("RF strength"), "outdoor.rf_status")
        self.addWidgets("Rainfall1", _("Rainfall: hour"), "outdoor.rainfall.1")
        self.addWidgets("Rainfall24", _("Rainfall: day"), "outdoor.rainfall.24")
        #self.addWidgets("ComfortClass", _("Comfort class"))
        self.onShown.append(self.setWindowTitle)
        self.onClose.append(self.onClosing)
        # last selection config
        self.last_station, self.last_module = evalConfigValue(config.Netatmo.selection_last)
        # hide wrong API values
        self["station.wifi_status"].hide()
        self["outdoor.rf_status"].hide()
        self["outdoor.battery"].hide()

    def addWidgets(self, name, text, _type=None):
        self[name] = Label(text)
        if _type:
            self[_type] = NetatmoLabel(_type, self[name])

    def addLabel(self, name):
        self[name] = NetatmoLabel(name)

    def setWindowTitle(self):
        simulated = config.Netatmo.simulate.value and " (simulated)" or ""
        self.setTitle(_("Netatmo") + simulated)
        p = resolveFilename(SCOPE_PLUGINS, IMAGE_PATH)
        # load co2 images
        if len(self["co2_pixmap"].pixmaps) != 10:
            self["co2_pixmap"].pixmaps = []
            for x in range(1, 11):
                self["co2_pixmap"].pixmaps.append(LoadPixmap(str.format("%sco2_%d.png" % (p, x))))
        if len(self["co2_pixmap_module"].pixmaps) != 10:
            self["co2_pixmap_module"].pixmaps = []
            for x in range(1, 11):
                self["co2_pixmap_module"].pixmaps.append(LoadPixmap(str.format("%sco2_%d.png" % (p, x))))
        # load wifi images
        image_list = ("wifi_unknown.png", "wifi_low.png", "wifi_medium.png", "wifi_high.png", "wifi_full.png")
        if len(self["wifi_pixmap"].pixmaps) != len(image_list):
            self["wifi_pixmap"].pixmaps = []
            for png in image_list:
                self["wifi_pixmap"].pixmaps.append(LoadPixmap(p + png))
        # load battery images
        image_list = ("battery_unknown.png", "battery_verylow.png", "battery_low.png", "battery_medium.png", "battery_high.png", "battery_full.png")
        if len(self["battery_pixmap"].pixmaps) != len(image_list):
            self["battery_pixmap"].pixmaps = []
            for png in image_list:
                self["battery_pixmap"].pixmaps.append(LoadPixmap(p + png))
        # load signal images
        image_list = ("signal_unknown.png", "signal_verylow.png", "signal_low.png", "signal_medium.png", "signal_high.png", "signal_full.png")
        if len(self["signal_pixmap"].pixmaps) != len(image_list):
            self["signal_pixmap"].pixmaps = []
            for png in image_list:
                self["signal_pixmap"].pixmaps.append(LoadPixmap(p + png))
        self.__timer.start(config.Netatmo.update_interval.value * 1000 * 60, False)
        self.updateStations()
        if config.Netatmo.select_last.value:
            self.select(self.last_station, self.last_module)
        
    def select(self, station_name, module_name):
        station = self["stations"].moveTo(station_name)
        if station:
            for index, m in enumerate(station.modules):
                if m.module_name == module_name:
                    station.module_index = index
                    break
        self.selectionChanged()

    def onClosing(self):
        self.__timer.stop()
        self.__timer = None
        self.__timer_conn = None
        self["stations"].disconnectSelChanged(self.selectionChanged)
        self.saveCurrentStation(config.Netatmo.selection_last)
    
    def saveCurrentStation(self, conf):
        station = netatmo.getStation()
        if station:
            module = station.getModule()
            module_name = module and module.module_name or ""
            conf.value = str([station.name, module_name])
            conf.save()
        
    def updateButtons(self):
        enabled = config.Netatmo.enabled.value and netatmo is not None and len(netatmo.stations) > 1
        if enabled:
            self["key_yellow"].show()
            self["key_blue"].show()
            self["button_yellow"].show()
            self["button_blue"].show()
        else:
            self["key_yellow"].hide()
            self["key_blue"].hide()
            self["button_yellow"].hide()
            self["button_blue"].hide()
    
    def updateStations(self):
        self.updateButtons()
        if netatmo is None or not config.Netatmo.enabled.value:
            self["stations"].setList([])
            return
        station_list = []
        for station in netatmo.stations:
            station_list.append((station,))
        if config.Netatmo.show_stationlist.value:
            self["stations"].setList(station_list)
        else:
            self["stations"].setList("")
        self["stations"].connectSelChanged(self.selectionChanged)
        self.selectionChanged()
    
    def getCO2PixNum(self, co2):
        y = float(co2 - 400)
        if co2 < 600:  
            x = y / 15
        else:
            x = y / 16
        # 
        if x >= 100:
            pix_num = 9
        elif x <= 0:
            pix_num = 0
        else:
            pix_num = int(x / 10.0)
        return pix_num
    
    def updateIcons(self, station):
        for item in self:
            if isinstance(self[item], NetatmoLabel):
                self[item].update()

        if station is None:
            self["wifi_pixmap"].setPixmapNum(0)
            self["signal_pixmap"].setPixmapNum(0)
            self["battery_pixmap"].setPixmapNum(0)
            return
        
        if station is not None:
            x = station.wifi_status
            if x < 55:
                self["wifi_pixmap"].setPixmapNum(4)
            elif x < 65:
                self["wifi_pixmap"].setPixmapNum(3)
            elif x < 75:
                self["wifi_pixmap"].setPixmapNum(2)
            elif x < 85:
                self["wifi_pixmap"].setPixmapNum(1)
            else:
                self["wifi_pixmap"].setPixmapNum(0)
            if station.indoor is not None:
                self["noise_slider"].setValue(station.indoor.noise)
                self["co2_pixmap"].setPixmapNum(self.getCO2PixNum(station.indoor.co2))
                
            m = station.getModule()
            if m is None:
                self["signal_pixmap"].setPixmapNum(0)
                self["battery_pixmap"].setPixmapNum(0)
            else:
                x = m.rf_status
                if x < 60:
                    self["signal_pixmap"].setPixmapNum(5)
                elif x < 70:
                    self["signal_pixmap"].setPixmapNum(4)
                elif x < 80:
                    self["signal_pixmap"].setPixmapNum(3)
                elif x < 90:
                    self["signal_pixmap"].setPixmapNum(2)
                elif x < 100:
                    self["signal_pixmap"].setPixmapNum(1)
                else:
                    self["signal_pixmap"].setPixmapNum(0)
                
                if m.battery_vp > 5500:
                    self["battery_pixmap"].setPixmapNum(5)
                elif m.battery_vp > 5000:
                    self["battery_pixmap"].setPixmapNum(4)
                elif m.battery_vp > 4500:
                    self["battery_pixmap"].setPixmapNum(3)
                elif m.battery_vp > 4000:
                    self["battery_pixmap"].setPixmapNum(2)
                elif m.battery_vp > 1:
                    self["battery_pixmap"].setPixmapNum(1)
                else:
                    self["battery_pixmap"].setPixmapNum(0)
                
                lables = ("Humidity outdoor", "outdoor.humidity")
                if m.module_type == 'NAModule3':
                    self["Temperature outdoor"].setText(_("Rainfall"))
                    self["outdoor.temperature"].setText(str(m.outdoor.getSensor(Sensor.Rain24)) + netatmo.getUint(NetatmoUnit.MM))
                    for l in lables: self[l].hide()
                else:
                    self["Temperature outdoor"].setText(_("Temperature"))
                    for l in lables: self[l].show()
                
                if m.outdoor.has_co2:
                    self["co2_pixmap_module"].setPixmapNum(self.getCO2PixNum(m.outdoor.co2))
                    self["co2_pixmap_module"].show()
                else:
                    self["co2_pixmap_module"].hide()
                
    def openMenu(self):
        self.session.openWithCallback(self.updateCallback, NetatmoSetup)
    
    def updateCallback(self):
        netatmoUpdater.update(False)
        self.updateStations()
    
    def selectPreferred(self):
        station, mdule = evalConfigValue(config.Netatmo.preferred)
        self.select(station, mdule)

    def savePreferred(self):
        self.saveCurrentStation(config.Netatmo.preferred)
    
    def getNetatmoText(self, station):
        if not config.Netatmo.enabled.value:
            return "Disabled..."
        l = []
        if netatmo.error is not None:
            return netatmo.error
        if station is not None:
            l.append("Station: " + station.module_name)
            l.append("Firmware: " + str(station.firmware))
            l.append("Area: " + str(station.area))
            if station.indoor is not None:
                l.append("Temperature: %s%s" % (station.indoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                l.append("Humidity: " + str(station.indoor.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY))
                l.append("Pressure: " + str(station.indoor.pressure) + netatmo.getUint(NetatmoUnit.PRESSURE))
                l.append("Co2: " + str(station.indoor.co2) + netatmo.getUint(NetatmoUnit.CO2))
                l.append("Noise: " + str(station.indoor.noise) + netatmo.getUint(NetatmoUnit.NOISE))
                
                for m in station.modules:
                    l.append("Module: " + m.module_name)
                    l.append("Firmware: " + str(m.firmware))
                    l.append("Battery: " + str(m.battery_vp))
                    if m.outdoor is not None:
                        l.append("Temperature: %s%s" % (m.outdoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE)))
                        l.append("Humidity: " + str(m.outdoor.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY))
        return "\n".join(l)

    def selectionChanged(self):
        #station = self["stations"].getCurrent()
        #text = self.getNetatmoText(station)
        #self["details"].setText(text.encode('utf8'))
        #self["details"].hide()
        netatmo.current_index = self["stations"].getCurrentIndex()
        self.updateCurrentStation()

    def pageUp(self):
        pass
        # self["details"].pageUp()

    def pageDown(self):
        pass
        # self["details"].pageDown()
    
    def left(self):
        netatmo.moduleIndex(-1)
        self.updateCurrentStation()
    
    def right(self):
        netatmo.moduleIndex(1)
        self.updateCurrentStation()

    def notifications(self):
        from Notification import netatmoNotificationUpdater
        netatmoNotificationUpdater.showPopup()
    
    def updateCurrentStation(self):
        station = netatmo.getStation()
        self.updateIcons(station)
        txt = _("Stations list:")
        if station is None:
            self["stations_txt"].setText("")
            return
        module_count = len(station.modules)
        if module_count <= 1:
            module_info = ""
        else:
            module_info = str.format(" (%d/%d)" % (station.module_index + 1, module_count)).encode('utf8')
        if config.Netatmo.show_stationlist.value:
            self["stations_txt"].setText(txt + module_info)
        else:
            self["stations_txt"].setText("")
