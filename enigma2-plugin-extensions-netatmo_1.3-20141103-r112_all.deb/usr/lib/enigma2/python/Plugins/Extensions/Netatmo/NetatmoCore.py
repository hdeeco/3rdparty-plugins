#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula and JackDaniel (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
'''
Client id            "517e9f21187759727300000c"
Client secret        "hfwlJcZ13nbJkv0CKwGt4FgV0Xas7s0Z"
Request token URL    "http://api.netatmo.net/oauth2/token"
Authorize URL        "http://api.netatmo.net/oauth2/authorize"
Callback URL         None
'''
### DO NOT IMPORT CLASSES FROM ENIGMA2 ###
from __init__ import _
from NetatmoAPI import ClientAuth, DeviceList, User
from datetime import datetime
import time
import urllib2
import json
### DO NOT IMPORT CLASSES FROM ENIGMA2 ###

def printStackTrace():
    import sys, traceback
    print "--- [Netatmo] STACK TRACE ---"
    traceback.print_exc(file=sys.stdout)
    print '-----------------------------'

class DataParser():
    def __init__(self, data, def_str="N/A", def_int=0):
        self.data = data
        self.def_str = def_str
        self.def_int = def_int
    
    def getNumber(self, key):
        try:
            val = self.data[key]
            if isinstance(val, int):
                return int(val)
            if isinstance(val, float):
                return round(float(val), 1)
            if isinstance(val, str):
                return str(val)
            return self.def_int
        except:
            printStackTrace()
            return self.def_int
        
    def getString(self, key):
        try:
            return unicode(self.data[key])
        except:
            printStackTrace()
            return self.def_str
        
    def getItem(self, key):
        try:
            return self.data[key]
        except:
            printStackTrace()
            return None
        

class UserData():
    def __init__(self, raw):
        data = raw["administrative"]
        p = DataParser(data)
        self.lang = p.getString("lang")
        self.reg_locale = p.getString("reg_locale")
        self.country = p.getString("country")
        self.unit = p.getNumber("unit")
        self.pressureunit = p.getNumber("pressureunit")
        self.windunit = p.getNumber("windunit")
        self.feel_like_algo = p.getNumber("feel_like_algo")
        #self.devices = p.getString("devices")
        #dict: {u'lang': u'de-DE', u'reg_locale': u'de', u'windunit': 0, u'feel_like_algo': 0, u'pressureunit': 0, u'country': u'DE', u'unit': 0}

class NetatmoUnit:
    TEMPERATURE = 0
    HUMIDITY = 1
    PRESSURE = 2
    NOISE = 3
    CO2 = 4
    MM = 5

class Sensor:
    When = 'time_utc'
    Temperature = 'Temperature'
    Co2 = 'CO2'
    Humidity = 'Humidity'
    Noise = 'Noise'
    Pressure = 'Pressure'
    Rain = 'Rain'
    Rain1 = 'sum_rain_1'
    Rain24 = 'sum_rain_24'

class Stations():
    CLIENT_ID = "517e9f21187759727300000c"
    CLIENT_SECRET = "hfwlJcZ13nbJkv0CKwGt4FgV0Xas7s0Z"
    SIMULATE = False
    def __init__(self):
        self.user = None
        self.stations = []
        self.error = None
        self.last_refresh = "N/A"
        self.current_index = 0
    
    def updateTimestamp(self):
        self.last_refresh = (_("Last refresh:") + ' ' + datetime.now().strftime("%d.%m.%Y %H:%M:%S"))
    
    def update(self, user, password):
        print "[Netatmo] update"
        try:
            new_station = []
            deviceList = DeviceList()
            if self.SIMULATE:
                self.user = UserData(DebugRawData.authorization)
                deviceList.raw = DebugRawData.device_list
            else:
                authorization = ClientAuth(self.CLIENT_ID, self.CLIENT_SECRET, user, password)
                self.user = UserData(User(authorization).rawData)
                deviceList.request(authorization)
            for x in deviceList.listDevices():
                station = Station(deviceList, x)
                new_station.append(station)
            # sort stations
            new_station.sort(key=lambda x: x.name.lower(), reverse=False)
            # set old module index
            if len(self.stations) == len(new_station):
                for index, s in enumerate(self.stations):
                    new_station[index].module_index = s.module_index
            self.stations = new_station
            self.error = None
            self.updateTimestamp()
            return True
        except Exception, e:
            self.error = str(e)
            printStackTrace()
    
    def getUint(self, unit):
        if self.user is None:
            return ""
        if unit == NetatmoUnit.TEMPERATURE:
            return self.user.unit == 0 and u" °C" or u" °F"
        if unit == NetatmoUnit.PRESSURE:
            if self.user.pressureunit == 0:
                return " mbar"
            if self.user.pressureunit == 1:
                return " inHg"
            if self.user.pressureunit == 2:
                return " mmHg"
        if unit == NetatmoUnit.HUMIDITY:
            return " %"
        if unit == NetatmoUnit.NOISE:
            return " db"
        if unit == NetatmoUnit.CO2:
            return " ppm"
        if unit == NetatmoUnit.MM:
            if self.user.unit == 1:
                return " in"
            if self.user.unit == 0:
                return " mm"
        return ""
    
    def moduleIndex(self, what):
        try:
            if len(self.stations) == 0:
                return
            if what > 0:
                self.getStation().nextIndex()
            else:
                self.getStation().prevIndex()
        except:
            printStackTrace()
    
    def getStation(self):
        if len(self.stations) == 0:
            return None
        return self.stations[self.current_index]
    
    def select(self, station, module):
        for index, s in enumerate(self.stations):
            if s.name == station:
                self.current_index = index
                break
        s = self.getStation()
        if s:
            for index, m in enumerate(s.modules):
                if m.module_name == module:
                    s.module_index = index
                    break

class Station():
    def __init__(self, raw, data):
        self.modules = []
        self.module_index = 0
        p = DataParser(data)
        self.name = p.getString("station_name")
        self.module_name = p.getString("module_name")
        self.firmware = p.getNumber("firmware")
        self.wifi_status = p.getNumber("wifi_status")
        p.data = data["place"]
        self.location = p.getItem("location")
        #self.area = p.getString("geoip_city").encode("utf-8")
        #self.area = p.getString("meteoalarm_area").encode("utf-8")
        device_location = p.getString("location").encode("utf-8").replace("[", "").replace("]", "").split(",")
        latitude = device_location[1]
        longitude = device_location[0]
        add = urllib2.quote(str(latitude + ',' + longitude))
        geocode_url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=%s&sensor=true_or_false" % add
        req = urllib2.urlopen(geocode_url)
        jsonResponse = json.load(req)
        area = jsonResponse['results'][0]['formatted_address']
        if area:
            self.area = area.encode("utf-8")
        else:
            self.area = _("No Google Geocoding possible!")
        self.timezone = p.getString("timezone")
        # "NAMain" : for the base station
        self.indoor = Indoor(raw, data)
        for module_id in data['modules']:
            m = raw.getModule(module_id)
            mod_type = m['type']
            # "NAModule1" : for the outdoor module
            # "NAModule4" : for the additional indoor module
            if mod_type in ('NAModule1', 'NAModule4'):
                module = Module(m)
                module.outdoor = Outdoor(raw, m)
                module.name = self.name
                self.modules.insert(0, module)
            # "NAModule3" : for the rain gauge module
            elif mod_type == 'NAModule3':
                module = Module(m)
                module.outdoor = NAModule3(raw, m)
                module.name = self.name
                self.modules.insert(0, module)
            #"NAPlug" : for the thermostat plug
            elif mod_type == 'NAPlug':
                print "[Netatmo] not implemented"
                print mod_type
                print raw.raw
                # TODO: implement
                pass
            # "NATherm1" : for the thermostat module
            elif mod_type == 'NATherm1':
                print "[Netatmo] not implemented"
                print mod_type
                print raw.raw
                # TODO: implement
                pass
            else:
                print "[Netatmo] unsupported module"
                print "Type: %s; Station: %s; Module: %s" % (mod_type, self.name, self.module_name)
                print m

        self.modules.sort(key=lambda x: x.module_name.lower(), reverse=False)

    def __repr__(self):
        return self.name
    
    def nextIndex(self):
        if self.module_index + 1 >= len(self.modules):
            self.module_index = 0
        else:
            self.module_index += 1
        #print self.module_index

    def prevIndex(self):
        if self.module_index - 1 < 0:
            self.module_index = len(self.modules) - 1
        else:
            self.module_index -= 1
        #print self.module_index
            
    def getModule(self):
        if len(self.modules) == 0:
            return None
        return self.modules[self.module_index]
    
    def findRainModule(self):
        for module in self.modules:
            if isinstance(module.outdoor, NAModule3):
                return module


class Module():
    def __init__(self, data):
        self.outdoor = None
        p = DataParser(data)
        self.module_type = data['type']
        self.module_name = p.getString("module_name")
        self.firmware = p.getNumber("firmware")
        self.battery_vp = p.getNumber("battery_vp")
        self.rf_status = p.getNumber("rf_status")
        self.main_device = p.getString("main_device")

    def __repr__(self):
        return self.module_name

def timeConverter(time_value):
    return time.strftime("%d.%m.%Y %H:%M", time.localtime(time_value))
        
class Indoor():
    def __init__(self, raw, m):
        data = raw.getDeviceData(m)
        self.module_type = m['type']
        self.module_name = m['module_name']
        p = DataParser(data)
        self.noise = p.getNumber(Sensor.Noise)
        self.temperature = p.getNumber(Sensor.Temperature)
        self.when = _("Last measurement:") + ' ' + timeConverter(p.getNumber(Sensor.When))
        self.humidity = p.getNumber(Sensor.Humidity)
        self.pressure = p.getNumber(Sensor.Pressure)
        self.co2 = p.getNumber(Sensor.Co2)

        import Comfort
        self.humidex = Comfort.humidex(self.temperature, self.humidity)    
        self.idx_temp = Comfort.comfort_temp(self.humidex)
        self.idx_co2 = Comfort.comfort_co2(self.co2)
        self.idx_noise = Comfort.comfort_noise(self.noise)
        self.idx_humidity = Comfort.comfort_humidity(self.humidity)
        self.idx_total = Comfort.comfort_fusion(self.idx_co2, self.idx_temp, self.idx_noise, self.idx_humidity)
        self.comf_class = Comfort.comfort_class(self.idx_total)
        if self.idx_total >= 50.0:
            self.dis_reason = Comfort.discomfort_reason(self.idx_co2, self.idx_temp, self.idx_noise, self.idx_humidity, self.humidex, self.humidity)
        else:
            self.dis_reason = ""

        if self.dis_reason:
            self.comf_class += " - " + self.dis_reason

        
    def __repr__(self):
        return str(self.temperature)
        
class Outdoor():
    def __init__(self, raw, m):
        data = raw.getModuleData(m)
        self.module_type = m['type']
        self.module_name = m['module_name']
        self.has_temperature = data.has_key(Sensor.Temperature)
        self.has_humidity = data.has_key(Sensor.Humidity)
        self.has_co2 = data.has_key(Sensor.Co2)
        self.has_rainfall = False
        self.co2 = 0
        self.humidity = 0
        self.temperature = 0
        p = DataParser(data)
        self.when = timeConverter(p.getNumber(Sensor.When))
        if self.has_temperature:
            self.temperature = p.getNumber(Sensor.Temperature)
        if self.has_humidity:
            self.humidity = p.getNumber(Sensor.Humidity)
        if self.has_co2:
            self.co2 = p.getNumber(Sensor.Co2)
        self.p = p
    
    def getSensor(self, sensor):
        return self.p.getNumber(sensor)
    
    def __repr__(self):
        return str(self.temperature) 

class NAModule3(Outdoor):
    def __init__(self, raw, m):
        Outdoor.__init__(self, raw, m)
        self.has_rainfall = True

def getLastData():
    user = ''
    password = ''
    netatmo = Stations()
    netatmo.update(user, password)
    printStation(netatmo.stations)

def printStation(stations):
    for station in stations:
        print station.name
        print station.module_name
        print station.firmware
        print station.wifi_status
        print station.location
        print station.area
        print station.timezone
        print station.indoor
        for module in station.modules:
            print module.module_name
            print module.firmware
            print module.battery_vp
            print module.rf_status
            print module.outdoor

class DebugRawData():
    # simulation file
    # line 1: authorization data (only one line) 
    # next lines: station and module data
    SIM_FILE = 'simulation.api'
    authorization = {u'timeline_not_read': 38, u'devices': [u'70:ee:50:01:6c:d6', u'70:ee:50:02:da:2c', u'70:ee:50:02:d2:10', u'70:ee:50:02:c5:18', u'70:ee:50:02:d1:c4', u'70:ee:50:02:bb:24'], u'mail': u'xyz@gmx.de', u'_id': u'3434a4324234324325655', u'administrative': {u'lang': u'de-DE', u'reg_locale': u'de', u'windunit': 0, u'feel_like_algo': 0, u'pressureunit': 0, u'country': u'DE', u'unit': 0}, u'date_creation': {u'usec': 0, u'sec': 1378837413}, u'friend_devices': []}
    device_list = \
    {
        u'devices': 
        [
            {u'station_name': u'Wohnhaus', u'module_name': u'B\xfcro', u'dashboard_data': {u'Temperature': 17.4, u'Humidity': 55, u'Pressure': 1016.7, u"'": 974.8, u'CO2': 900, u'time_utc': 1392541634, u'Noise': 40}, u'last_marks': [None, None, 14], u'netcom_transport': u'tcp', u'public_ext_data': True, u'consolidation_date': 1392590202, u'last_event_stored': 1390236040, u'last_status_store': 1392541646, u'wifi_status': 59, u'friend_users': [u'52e9279219775922706d2739'], u'rf_amb_status': 122, u'last_alarm_stored': 1388229709, u'firmware': 86, u'mark': 14, u'streaming_key': u'da74c760b92dae52', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 607000, u'sec': 1378837648}, u'last_mark_time': {u'usec': 341000, u'sec': 1392526765}, u'access_code': u'qb0okUqD65FF6DP', u'update_device': False, u'hw_version': 251, u'modules': [u'05:00:00:00:1f:d8', u'03:00:00:00:31:7e', u'03:00:00:01:31:7e', u'03:00:00:02:31:7e', u'02:00:00:01:80:50', u'03:00:00:00:30:d8', u'03:00:00:00:3f:b0'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'24:65:11:86:0d:61', u'country': u'DE', u'altitude': 354, u'location': [11.70143, 48.77222], u'timezone': u'Europe/Berlin', u'meteoalarm_area': u'Bayern'}, u'_id': u'70:ee:50:01:6c:d6', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': []}, u'invitation_disable': False},
            {u'station_name': u'Bergh\xfctte', u'module_name': u'Innen', u'dashboard_data': {u'Temperature': 13.8, u'Humidity': 55, u'Pressure': 1016.9, u"'": 975, u'CO2': 499, u'time_utc': 1392541707, u'Noise': 54}, u'last_marks': [None, None, None], u'netcom_transport': u'tcp', u'public_ext_data': False, u'consolidation_date': 1392558283, u'last_event_stored': 1392312711, u'last_status_store': 1392541720, u'wifi_status': 62, u'rf_amb_status': 106, u'firmware': 87, u'mark': None, u'streaming_key': u'f186597fa3653a66', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 652000, u'sec': 1392049592}, u'last_mark_time': {u'usec': 805000, u'sec': 1392526745}, u'access_code': u'IIPsKH9tj5vxwkm', u'update_device': False, u'hw_version': 251, u'modules': [u'02:00:00:02:b5:6c', u'03:00:00:00:a8:96'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'24:65:11:89:2f:64', u'country': u'DE', u'altitude': 354, u'location': [11.701339244843, 48.772266868853], u'timezone': u'Europe/Berlin', u'meteoalarm_area': u'\xd6sterreich'}, u'_id': u'70:ee:50:02:da:2c', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': []}, u'invitation_disable': False},
            {u'station_name': u'Arbeit', u'module_name': u'Arbeitszimmer', u'dashboard_data': {u'Temperature': 24.8, u'Humidity': 30, u'Pressure': 1014.3, u"'": 963.6, u'CO2': 815, u'time_utc': 1392541989, u'Noise': 59}, u'last_marks': [0, 0, 0], u'netcom_transport': u'http', u'public_ext_data': False, u'consolidation_date': 1392557614, u'setpoint_default_duration': 0, u'last_event_stored': 1392198265, u'last_status_store': 1392541997, u'wifi_status': 60, u'friend_users': [], u'rf_amb_status': 99, u'last_alarm_stored': 1391589993, u'firmware': 87, u'mark': 0, u'streaming_key': u'd90747a9923dc465', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 417000, u'sec': 1391589936}, u'last_mark_time': {u'usec': 948000, u'sec': 1392526793}, u'access_code': u'rqQHjEwCC7FV200DErM', u'update_device': False, u'hw_version': 251, u'modules': [u'02:00:00:02:cf:10'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'64:a0:e7:88:37:52', u'country': u'DE', u'altitude': 431, u'location': [11.803004980087, 48.455751553498], u'timezone': u'Europe/Berlin', u'meteoalarm_area': u'Bayern'}, u'_id': u'70:ee:50:02:d2:10', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': [{u'threshold': 26, u'direction': 0, u'db_alarm_number': 8, u'data_type': 1}, {u'threshold': 26, u'direction': 0, u'db_alarm_number': 18, u'data_type': 0}]}, u'invitation_disable': False},
            {u'station_name': u'Sommer Residenz', u'module_name': u'Innen', u'dashboard_data': {u'Temperature': 24, u'Humidity': 29, u'Pressure': 1016, u"'": 965.2, u'CO2': 406, u'time_utc': 1392541938, u'Noise': 53}, u'last_marks': [None, 0, None], u'netcom_transport': u'http', u'public_ext_data': False, u'consolidation_date': 1392605115, u'setpoint_default_duration': 0, u'last_event_stored': 1392197390, u'last_status_store': 1392541943, u'wifi_status': 85, u'friend_users': [], u'rf_amb_status': 104, u'firmware': 87, u'mark': 0, u'streaming_key': u'32901406377b8616', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 169000, u'sec': 1391593100}, u'last_mark_time': {u'usec': 602000, u'sec': 1392526842}, u'access_code': u'QCCbsEeKz6y', u'update_device': False, u'hw_version': 251, u'modules': [u'02:00:00:02:ee:be'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'64:a0:e7:88:37:52', u'country': u'DE', u'altitude': 431, u'location': [11.802876234055, 48.455829822237], u'timezone': u'Europe/Berlin', u'meteoalarm_area': u'Italien'}, u'_id': u'70:ee:50:02:c5:18', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': [{u'threshold': 28, u'direction': 0, u'db_alarm_number': 8, u'data_type': 1}, {u'threshold': 28, u'direction': 0, u'db_alarm_number': 18, u'data_type': 0}]}, u'invitation_disable': False},
            {u'station_name': u'Mondsee', u'module_name': u'Innen', u'dashboard_data': {u'Temperature': 19.4, u'Humidity': 34, u'Pressure': 1016.7, u"'": 965.8, u'CO2': 409, u'time_utc': 1392542187, u'Noise': 53}, u'last_marks': [0, 0, None], u'netcom_transport': u'http', u'public_ext_data': False, u'consolidation_date': 1392575100, u'setpoint_default_duration': 0, u'last_event_stored': 1392197602, u'last_status_store': 1392542199, u'wifi_status': 54, u'friend_users': [], u'rf_amb_status': 103, u'last_alarm_stored': 1392197052, u'service': {u'meteo_alarm': False}, u'firmware': 87, u'mark': 0, u'streaming_key': u'cba03eb5398919d3', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 432000, u'sec': 1390985398}, u'last_mark_time': {u'usec': 666000, u'sec': 1392526797}, u'access_code': u'8iHycfQ1dx8y7LPsBgp', u'update_device': False, u'hw_version': 251, u'modules': [u'02:00:00:02:c5:7e'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'64:a0:e7:88:37:52', u'country': u'DE', u'altitude': 431, u'location': [11.802962064743, 48.455737322805], u'timezone': u'Europe/Berlin', u'meteoalarm_area': u'\xd6sterreich'}, u'_id': u'70:ee:50:02:d1:c4', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': [{u'threshold': 26, u'direction': 0, u'db_alarm_number': 18, u'data_type': 0}]}, u'invitation_disable': False},
            {u'station_name': u'Italien', u'module_name': u'Innen', u'dashboard_data': {u'Temperature': 21.4, u'Humidity': 35, u'Pressure': 1015.8, u"'": 965, u'CO2': 420, u'time_utc': 1392542070, u'Noise': 35}, u'last_marks': [None, None, 15], u'netcom_transport': u'http', u'public_ext_data': True, u'consolidation_date': 1392566327, u'last_event_stored': 1392278869, u'last_status_store': 1392542084, u'wifi_status': 62, u'rf_amb_status': 107, u'firmware': 87, u'mark': 15, u'streaming_key': u'2ef055db58042316', u'type': u'NAMain', u'data_type': [u'Temperature', u'Co2', u'Humidity', u'Noise', u'Pressure'], u'date_setup': {u'usec': 583000, u'sec': 1392278538}, u'last_mark_time': {u'usec': 713000, u'sec': 1392526745}, u'access_code': u'68jxVGipbchBfoB', u'update_device': False, u'hw_version': 251, u'modules': [u'02:00:00:02:d7:60'], u'co2_calibrating': False, u'place': {u'trust_location': True, u'bssid': u'00:3a:99:e5:aa:72', u'country': u'DE', u'altitude': 431, u'location': [11.802715301514, 48.455723092109], u'timezone': u'Europe/Rom', u'meteoalarm_area': u'Italien'}, u'_id': u'70:ee:50:02:bb:24', u'alarm_config': {u'default_alarm': [{u'desactivated': True, u'db_alarm_number': 0}, {u'desactivated': True, u'db_alarm_number': 1}, {u'desactivated': True, u'db_alarm_number': 2}, {u'desactivated': True, u'db_alarm_number': 6}, {u'desactivated': True, u'db_alarm_number': 4}, {u'desactivated': True, u'db_alarm_number': 5}, {u'desactivated': True, u'db_alarm_number': 7}], u'personnalized': []}, u'invitation_disable': False},
        ],
        u'modules': 
        [
            {u'module_name': u'Regenmesser', u'dashboard_data': {u'time_utc': 1400847329, u'sum_rain_24': 9.191, u'sum_rain_1': 0, u'Rain': 0}, u'rf_status': 84, u'last_alarm_stored': 1399478527, u'data_type': [u'Rain'], u'last_message': 1399712561, u'manual_pairing': True, u'firmware': 5, u'last_event_stored': 1399306700, u'pluvio_scale_auget_to_mm': 0.101, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 6342, u'_id': u'05:00:00:00:1f:d8', u'type': u'NAModule3', u'last_seen': 1399712555},
            {u'module_name': u'Badezimmer 1', u'dashboard_data': {u'Temperature': 22.3, u'CO2': 879, u'time_utc': 1392541586, u'Humidity': 38}, u'rf_status': 0, u'last_alarm_stored': 1388225106, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541644, u'manual_pairing': True, u'firmware': 31, u'last_event_stored': 1392237355, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5239, u'_id': u'03:00:00:00:31:7e', u'type': u'NAModule4', u'last_seen': 1392541637},
            {u'module_name': u'Badezimmer 2', u'dashboard_data': {u'Temperature': 23.3, u'CO2': 479, u'time_utc': 1392541586, u'Humidity': 38}, u'rf_status': 10, u'last_alarm_stored': 1388225106, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541644, u'manual_pairing': True, u'firmware': 32, u'last_event_stored': 1392237355, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5239, u'_id': u'03:00:00:01:31:7e', u'type': u'NAModule4', u'last_seen': 1392541637},
            {u'module_name': u'Badezimmer 3', u'dashboard_data': {u'Temperature': 24.3, u'CO2': 279, u'time_utc': 1392541586, u'Humidity': 38}, u'rf_status': 90, u'last_alarm_stored': 1388225106, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541644, u'manual_pairing': True, u'firmware': 33, u'last_event_stored': 1392237355, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5239, u'_id': u'03:00:00:02:31:7e', u'type': u'NAModule4', u'last_seen': 1392541637},
            {u'module_name': u'K\xfcche', u'dashboard_data': {u'Temperature': 22.9, u'CO2': 534, u'time_utc': 1392541599, u'Humidity': 39}, u'rf_status': 40, u'last_alarm_stored': 1388162150, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541644, u'manual_pairing': True, u'firmware': 37, u'last_event_stored': 1385615358, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5299, u'_id': u'03:00:00:00:3f:b0', u'type': u'NAModule4', u'last_seen': 1392541599},
            {u'module_name': u'Terrasse', u'dashboard_data': {u'Temperature': 5.5, u'time_utc': 1392541618, u'Humidity': 86}, u'rf_status': 60, u'last_alarm_stored': 1391974905, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392541644, u'firmware': 37, u'last_event_stored': 1389639684, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5738, u'_id': u'02:00:00:01:80:50', u'type': u'NAModule1', u'last_seen': 1392541618},
            {u'module_name': u'Wohnzimmer', u'dashboard_data': {u'Temperature': 17.2, u'CO2': 1814, u'time_utc': 1392541605, u'Humidity': 48}, u'rf_status': 80, u'last_alarm_stored': 1388224550, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541644, u'manual_pairing': True, u'firmware': 37, u'last_event_stored': 1391202724, u'main_device': u'70:ee:50:01:6c:d6', u'battery_vp': 5246, u'_id': u'03:00:00:00:30:d8', u'type': u'NAModule4', u'last_seen': 1392541605},
            {u'module_name': u'Au\xdfen', u'dashboard_data': {u'Temperature': 26.3, u'time_utc': 1392541906, u'Humidity': 24}, u'rf_status': 30, u'last_alarm_stored': 1392230624, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392541939, u'firmware': 38, u'last_event_stored': 1392198841, u'main_device': u'70:ee:50:02:c5:18', u'battery_vp': 4202, u'_id': u'02:00:00:02:ee:be', u'type': u'NAModule1', u'last_seen': 1392541906},
            {u'module_name': u'Terrasse', u'dashboard_data': {u'Temperature': 5.6, u'time_utc': 1392541692, u'Humidity': 81}, u'rf_status': 84, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392541717, u'firmware': 38, u'last_event_stored': 1392533254, u'main_device': u'70:ee:50:02:da:2c', u'battery_vp': 6258, u'_id': u'02:00:00:02:b5:6c', u'type': u'NAModule1', u'last_seen': 1392541692},
            {u'module_name': u'Wintergarten', u'dashboard_data': {u'Temperature': 20.3, u'CO2': 659, u'time_utc': 1392541705, u'Humidity': 39}, u'rf_status': 68, u'data_type': [u'Temperature', u'Co2', u'Humidity'], u'last_message': 1392541717, u'manual_pairing': True, u'firmware': 38, u'last_event_stored': 1392312989, u'main_device': u'70:ee:50:02:da:2c', u'battery_vp': 6263, u'_id': u'03:00:00:00:a8:96', u'type': u'NAModule4', u'last_seen': 1392541705},
            {u'module_name': u'Garage', u'dashboard_data': {u'Temperature': 22.6, u'time_utc': 1392541956, u'Humidity': 34}, u'rf_status': 57, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392541994, u'firmware': 38, u'last_event_stored': 1392199088, u'main_device': u'70:ee:50:02:d2:10', u'battery_vp': 6258, u'_id': u'02:00:00:02:cf:10', u'type': u'NAModule1', u'last_seen': 1392541956},
            {u'module_name': u'Terrasse', u'dashboard_data': {u'Temperature': 23.5, u'time_utc': 1392542157, u'Humidity': 27}, u'rf_status': 61, u'last_alarm_stored': 1391179607, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392542195, u'manual_pairing': True, u'firmware': 38, u'last_event_stored': 1392199090, u'main_device': u'70:ee:50:02:d1:c4', u'battery_vp': 6110, u'_id': u'02:00:00:02:c5:7e', u'type': u'NAModule1', u'last_seen': 1392542157},
            {u'module_name': u'Strand', u'dashboard_data': {u'Temperature': 5.8, u'time_utc': 1392542067, u'Humidity': 94}, u'rf_status': 76, u'data_type': [u'Temperature', u'Humidity'], u'last_message': 1392542080, u'firmware': 38, u'last_event_stored': 1392291903, u'main_device': u'70:ee:50:02:bb:24', u'battery_vp': 6044, u'_id': u'02:00:00:02:d7:60', u'type': u'NAModule1', u'last_seen': 1392542067},
        ],
    }
    
    def readAuthorization(self):
        f = open(DebugRawData.SIM_FILE)
        data = "".join(f.readline())
        f.close()
        return eval(data)

    def readDeviceList(self):
        f = open(DebugRawData.SIM_FILE)
        f.readline()
        data = "".join(f.readlines())
        f.close()
        return eval(data)

if __name__ == "__main__":
    user = UserData(DebugRawData.authorization)
    print user.lang
    raw = DebugRawData.device_list
    for dev in raw['devices']:
        print dev['type'], dev['station_name'], dev['module_name']
        for mod_id in dev['modules']:
            module = next((x for x in raw['modules'] if x['_id'] == mod_id), None)
            print module['type'], module['module_name']
    
    #getLastData()
