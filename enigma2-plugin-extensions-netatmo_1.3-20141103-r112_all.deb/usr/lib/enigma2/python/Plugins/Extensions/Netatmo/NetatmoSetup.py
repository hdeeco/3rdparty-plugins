#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula and JackDaniel(c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Screens.Screen import Screen
from Components.Sources.StaticText import StaticText
from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry, ConfigYesNo, ConfigInteger, ConfigNothing
from Components.ConfigList import ConfigListScreen

class NetatmoSetup(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self["setupActions"] = ActionMap(["ColorActions", "OkCancelActions", "MenuActions"],
        {
            "ok": self.keySave,
            "cancel": self.close,
            "red": self.close,
            "green": self.keySave,
        }, -2)
        self["key_red"] = StaticText(_("Close"))
        self["key_green"] = StaticText(_("Save"))
        self.list = []
        ConfigListScreen.__init__(self, self.list, session=self.session)
        self.initializeNetatmoConfig()
        self.createSetup()
        self.onShown.append(self.setWindowTitle)

    def setWindowTitle(self):
        self.setTitle(_("Netatmo setup"))
    
    def initializeNetatmoConfig(self):
        from Netatmo import netatmo
        self.nl = {}
        for station in netatmo.stations:
            if station.indoor:
                name = station.name
                d = {}
                d['module'] = {}
                d['Station'] = {'enabled':ConfigYesNo(False), 'name':name }
                d['Temperature_U'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(24, (1, 50)) }
                d['Temperature_L'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(0, (-30, 20)) }
                d['Humidity'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(50, (0, 100)) }
                d['Pressure'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(1100, (1, 1500)) }
                d['Noise'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(80, (1, 200)) }
                d['Co2'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(1500, (1, 2500)) }
                self.nl[name] = d
                for module in station.modules:
                    d = {}
                    if module.outdoor.has_temperature:
                        d['Temperature_U'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(24, (1, 50)) }
                        d['Temperature_L'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(0, (-30, 20)) }
                    if module.outdoor.has_humidity:
                        d['Humidity'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(50, (0, 100)) }
                    if module.outdoor.has_rainfall:
                        d['Rainfall1'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(10, (1, 10000)) }
                        d['Rainfall24'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(10, (1, 10000)) }
                    d['Battery'] = {'enabled':ConfigYesNo(False), 'limit':ConfigInteger(4500, (1500, 7000)) }
                    self.nl[name]['module'][module.module_name] = d
        
        try:
            conf = eval(config.Netatmo.notifications.value)
            if not isinstance(conf, dict):
                return;
            self.evalConfig(conf, self.nl)
        except:
            pass        
    
    def evalConfig(self, conf, d):
        for x in d:
            if conf.has_key(x):
                for y in conf[x]:
                    if y == 'module':
                        self.evalConfig(conf[x][y], d[x][y])
                        continue
                    if not conf[x][y].has_key('limit'):
                        continue
                    d[x][y]['enabled'].value = True
                    d[x][y]['limit'].value = int(conf[x][y]['limit'])

    def getConfig(self, nl):
        di = {}
        for x in nl:
            if nl[x].has_key('module'):
                m = self.getConfig(nl[x]['module'])
                if len(m) > 0:
                    di[x] = {}
                    di[x]['module'] = self.getConfig(nl[x]['module'])
            for y in nl[x]:
                if nl[x][y].has_key('limit') and nl[x][y].has_key('enabled') and nl[x][y]['enabled'].value:
                    if not di.has_key(x):
                        di[x] = {}
                    di[x][y] = {'limit': str(nl[x][y]['limit'].value) }
        return di
    
    def keySave(self):
        d = self.getConfig(self.nl)
        config.Netatmo.notifications.value = str(d)
        config.Netatmo.notifications.save()
        ConfigListScreen.keySave(self)

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.checkListentrys()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.checkListentrys()
        
    def checkListentrys(self):
        self.createSetup()
            
    def createSetup(self):
        self.list = []
        self.list.append(getConfigListEntry(_("Enable:"), config.Netatmo.enabled))
        self.list.append(getConfigListEntry(_("Open last selected station/module:"), config.Netatmo.select_last))
        self.list.append(getConfigListEntry(_("Update interval (minutes):"), config.Netatmo.update_interval))
        self.list.append(getConfigListEntry(_("User:"), config.Netatmo.user))
        self.list.append(getConfigListEntry(_("Password:"), config.Netatmo.password))
        self.list.append(getConfigListEntry(_("Show with info bar:"), config.Netatmo.show_netatmobar))
        self.list.append(getConfigListEntry(_("Show station list:"), config.Netatmo.show_stationlist))
        self.list.append(getConfigListEntry(_("Show info notification(s):"), config.Netatmo.show_notification))
        if config.Netatmo.show_notification.value:
            from Netatmo import netatmo
            from NetatmoCore import NetatmoUnit
            unit_temp = netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8').strip()
            unit_pressure = netatmo.getUint(NetatmoUnit.PRESSURE).encode('utf8').strip()
            self.list.append(getConfigListEntry(_("Notification time (in seconds):"), config.Netatmo.notifictaion_time))
            for x in self.nl:
                d = self.nl[x]
                self.list.append(getConfigListEntry(_("Station limits:") + " " + x.encode("utf-8"), d['Station']['enabled']))
                if not d['Station']['enabled'].value:
                    continue
                self.list.append(getConfigListEntry(_("Temperature notification upper limit:") + " " + x.encode("utf-8"), d['Temperature_U']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Temperature upper limit (%s):") % unit_temp, d['Temperature_U']['limit']))
                self.list.append(getConfigListEntry(_("Temperature notification lower limit:") + " " + x.encode("utf-8"), d['Temperature_L']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Temperature lower limit (%s):") % unit_temp, d['Temperature_L']['limit']))

                self.list.append(getConfigListEntry(_("Humidity notification:") + " " + x.encode("utf-8"), d['Humidity']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Humidity limit (%):"), d['Humidity']['limit']))
                
                self.list.append(getConfigListEntry(_("Pressure notification:") + " " + x.encode("utf-8"), d['Pressure']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Pressure limit (%s):") % unit_pressure, d['Pressure']['limit']))
                
                self.list.append(getConfigListEntry(_("Noise notification:") + " " + x.encode("utf-8"), d['Noise']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Noise limit (dB):"), d['Noise']['limit']))
                
                self.list.append(getConfigListEntry(_("Co2 notification:") + " " + x.encode("utf-8"), d['Co2']['enabled']))
                if self.list[-1][1].value:
                    self.list.append(getConfigListEntry(_("Co2 limit (ppm):"), d['Co2']['limit']))
                
                for xx in d['module']:
                    dd = d['module'][xx]
                    if dd.has_key('Temperature_U'):
                        self.list.append(getConfigListEntry(_("Temperature notification upper limit:") + " " + xx.encode("utf-8"), dd['Temperature_U']['enabled']))
                        if self.list[-1][1].value:
                            self.list.append(getConfigListEntry(_("Temperature upper limit (%s):") % unit_temp, dd['Temperature_U']['limit']))
                    if dd.has_key('Temperature_L'):
                        self.list.append(getConfigListEntry(_("Temperature notification lower limit:") + " " + xx.encode("utf-8"), dd['Temperature_L']['enabled']))
                        if self.list[-1][1].value:
                            self.list.append(getConfigListEntry(_("Temperature lower limit (%s):") % unit_temp, dd['Temperature_L']['limit']))
                    if dd.has_key('Humidity'):
                        self.list.append(getConfigListEntry(_("Humidity notification:") + " " + xx.encode("utf-8"), dd['Humidity']['enabled']))
                        if self.list[-1][1].value:
                            self.list.append(getConfigListEntry(_("Humidity limit (%):"), dd['Humidity']['limit']))
                    if dd.has_key('Rainfall1'):
                        self.list.append(getConfigListEntry(_("Rainfall notification (hour):") + " " + xx.encode("utf-8"), dd['Rainfall1']['enabled']))
                        if self.list[-1][1].value:
                            self.list.append(getConfigListEntry(_("Rainfall limit (mm/hour):"), dd['Rainfall1']['limit']))
                    if dd.has_key('Rainfall24'):
                        self.list.append(getConfigListEntry(_("Rainfall notification (day):") + " " + xx.encode("utf-8"), dd['Rainfall24']['enabled']))
                        if self.list[-1][1].value:
                            self.list.append(getConfigListEntry(_("Rainfall limit (mm/day):"), dd['Rainfall24']['limit']))

                    self.list.append(getConfigListEntry(_("Battery notification:") + " " + xx.encode("utf-8"), dd['Battery']['enabled']))
                    if self.list[-1][1].value:
                        self.list.append(getConfigListEntry(_("Battery limit (millivolt):"), dd['Battery']['limit']))

                self.list.append(getConfigListEntry("-"*40, ConfigNothing()))
                
                
        self["config"].setList(self.list)
