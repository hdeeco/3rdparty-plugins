#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula and JackDaniel (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Components.config import config
from Screens.MessageBox import MessageBox
from Netatmo import netatmo
from NetatmoCore import NetatmoUnit
from Tools import Notifications
import Screens.Standby

# check notification queue only supports oe2.0
REGISTERED_DOMAIN = "Netatmo"
try:
    Notifications.notificationQueue.registerDomain(REGISTERED_DOMAIN, _("Netatmo"), Notifications.ICON_DEFAULT)
    print "[Netatmo] register notification domain"
except:
    REGISTERED_DOMAIN = None
    print "[Netatmo] register notification domain failed"


class NetatmoNotificationUpdater():
    def __init__(self):
        from timer import eTimer
        self.__timer = eTimer()
        self.__timer_conn = self.__timer.timeout.connect(self.showPopup)
    
    def updateTimer(self, configElement):
        self.__timer.start(configElement.value * 1000 * 60, False)
        self.showPopup()
    
    def getLimit(self, conf, name, type):
        if conf.has_key(name):
            if conf[name].has_key(type):
                return int(conf[name][type]['limit'])
        return None

    def getModuleLimit(self, conf, name, module, type):
        if conf.has_key(name) and conf[name].has_key('module'):
            if conf[name]['module'].has_key(module) and conf[name]['module'][module].has_key(type):
                return int(conf[name]['module'][module][type]['limit'])
        return None
    
    def showPopup(self):
        print "[Netatmo] show popup"
        if len(netatmo.stations) == 0:
            return
        try:
            conf = eval(config.Netatmo.notifications.value)
            if not isinstance(conf, dict):
                return;
        except:
            return     
        msg = []
        for station in netatmo.stations:
            if station.indoor:
                name = station.name
                limit = self.getLimit(conf, name, 'Temperature_U')
                if limit and station.indoor.temperature >= limit:
                    msg.append(_("Temperature upper limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')))
                limit = self.getLimit(conf, name, 'Temperature_L')
                if limit and station.indoor.temperature <= limit:
                    msg.append(_("Temperature lower limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')))
                
                limit = self.getLimit(conf, name, 'Humidity')
                if limit and station.indoor.humidity >= limit:
                    msg.append(_("Humidity limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY).encode('utf8')))
                
                limit = self.getLimit(conf, name, 'Pressure')
                if limit and station.indoor.pressure >= limit:
                    msg.append(_("Pressure limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.pressure, netatmo.getUint(NetatmoUnit.PRESSURE).encode('utf8')))
                
                limit = self.getLimit(conf, name, 'Noise')
                if limit and station.indoor.noise >= limit:
                    msg.append(_("Noise limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.noise, netatmo.getUint(NetatmoUnit.NOISE).encode('utf8')))
                
                limit = self.getLimit(conf, name, 'Co2')
                if limit and station.indoor.co2 >= limit:
                    msg.append(_("CO2 limit reached"))
                    msg.append(" * %s - %s: %d%s" % (name.encode('utf8'), station.module_name.encode('utf8'), station.indoor.co2, netatmo.getUint(NetatmoUnit.CO2).encode('utf8')))
                
            for module in station.modules:
                limit = self.getModuleLimit(conf, name, module.module_name, 'Temperature_U')
                if limit and module.outdoor.temperature >= limit:
                    msg.append(_("Temperature upper limit reached"))
                    msg.append(" * %s - %s: %d%s" % (module.name.encode('utf8'), module.module_name.encode('utf8'), module.outdoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')))
                limit = self.getModuleLimit(conf, name, module.module_name, 'Temperature_L')
                if limit and module.outdoor.temperature >= limit:
                    msg.append(_("Temperature lower limit reached"))
                    msg.append(" * %s - %s: %d%s" % (module.name.encode('utf8'), module.module_name.encode('utf8'), module.outdoor.temperature, netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')))

                limit = self.getModuleLimit(conf, name, module.module_name, 'Humidity')
                if limit and module.outdoor.humidity >= limit:
                    msg.append(_("Humidity limit reached"))
                    msg.append(" * %s - %s: %d%s" % (module.name.encode('utf8'), module.module_name.encode('utf8'), module.outdoor.humidity, netatmo.getUint(NetatmoUnit.HUMIDITY).encode('utf8')))
                
                limit = self.getModuleLimit(conf, name, module.module_name, 'Battery')
                if limit and module.battery_vp <= limit:
                    msg.append(_("Low battery voltage"))
                    msg.append(" * %s - %s:  %0.3f V" % (module.name.encode('utf8'), module.module_name.encode('utf8'), module.battery_vp / 1000.0)) 
        
        if len(msg) > 0 and not Screens.Standby.inStandby:
            txt = "\n".join(msg)
            print "-" * 80
            print txt
            print "-" * 80
            if REGISTERED_DOMAIN:
                Notifications.AddNotification(MessageBox, txt, type=MessageBox.TYPE_INFO, timeout=config.Netatmo.notifictaion_time.value, domain=REGISTERED_DOMAIN)
            else:
                Notifications.AddNotification(MessageBox, txt, type=MessageBox.TYPE_INFO, timeout=config.Netatmo.notifictaion_time.value)

netatmoNotificationUpdater = NetatmoNotificationUpdater()
