#!/usr/bin/python
# -*- coding: utf-8 -*-
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from __init__ import _
from Screens.InfoBar import InfoBar, MoviePlayer
from Screens.Screen import Screen
from Components.config import config
from Components.Label import Label
from Components.Converter.Netatmo import Netatmo

class NetatmoBar(Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.skinName = "NetatmoBar_V1"
        # disable labels - only use converter
        return
        self['station.name'] = Label()
        self['indoor.module_name'] = Label()
        self['indoor.temperature'] = Label()
        self['indoor.humidity'] = Label()
        self['indoor.co2'] = Label()
        self['indoor.noise'] = Label()
        self['outdoor.module_name'] = Label()
        self['outdoor.temperature'] = Label()
        self['outdoor.humidity'] = Label()
        self.onShow.append(self.update)
    
    def update(self):
        self['station.name'].setText(Netatmo("station.name").getText())
        self['indoor.module_name'].setText(Netatmo("indoor.module_name").getText())
        self['indoor.temperature'].setText("%s: %s" % (_("Temperature"), Netatmo("indoor.temperature").getText()))
        self['indoor.humidity'].setText("%s: %s" % (_("Humidity"), Netatmo("indoor.humidity").getText()))
        self['indoor.co2'].setText("%s: %s" % (_("CO2"), Netatmo("indoor.co2").getText()))
        self['indoor.noise'].setText("%s: %s" % (_("Noise"), Netatmo("indoor.noise").getText()))
        self['outdoor.module_name'].setText(Netatmo("outdoor.module_name").getText())
        self['outdoor.temperature'].setText("%s: %s" % (_("Temperature"), Netatmo("outdoor.temperature").getText()))
        self['outdoor.humidity'].setText("%s: %s" % (_("Humidity"), Netatmo("outdoor.humidity").getText()))

def initNetatmoBar():
    def showNetatmoBar(self):
        if config.Netatmo.show_netatmobar.value:
            self.netatmo_bar.show()
    
    def hideNetatmoBar(self):
        self.netatmo_bar.hide()
    
    def InfoBar__init__(self, session):
        eInfoBar__init__(self, session)
        self.netatmo_bar = session.instantiateDialog(NetatmoBar)
        self.onShow.append(self.showNetatmoBar)
        self.onHide.append(self.hideNetatmoBar)

    def MoviePlayer__init__(self, session, service):
        eMoviePlayer__init__(self, session, service)
        self.netatmo_bar = session.instantiateDialog(NetatmoBar)
        self.onShow.append(self.showNetatmoBar)
        self.onHide.append(self.hideNetatmoBar)
    
    InfoBar.showNetatmoBar = showNetatmoBar
    InfoBar.hideNetatmoBar = hideNetatmoBar
    eInfoBar__init__ = InfoBar.__init__
    InfoBar.__init__ = InfoBar__init__
    
    MoviePlayer.showNetatmoBar = showNetatmoBar
    MoviePlayer.hideNetatmoBar = hideNetatmoBar
    eMoviePlayer__init__ = MoviePlayer.__init__
    MoviePlayer.__init__ = MoviePlayer__init__
