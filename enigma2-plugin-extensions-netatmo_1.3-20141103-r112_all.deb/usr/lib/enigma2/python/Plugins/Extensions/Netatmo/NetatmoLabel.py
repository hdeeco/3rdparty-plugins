from Components.GUIComponent import GUIComponent
from Components.VariableText import VariableText
from enigma import eLabel
from Components.Converter.Netatmo import Netatmo

class NetatmoLabel(VariableText, GUIComponent, Netatmo):
	def __init__(self, type, label=None, update=False):
		GUIComponent.__init__(self)
		VariableText.__init__(self)
		self.type = type
		self.label_desc = label
		if update:
			self.update()
	
	def update(self):
		txt = Netatmo.getText(self)
		if self.label_desc is not None:
			if txt == "" or txt is None:
				self.label_desc.hide()
			else:
				self.label_desc.show()
		self.setText(txt)

	GUI_WIDGET = eLabel
