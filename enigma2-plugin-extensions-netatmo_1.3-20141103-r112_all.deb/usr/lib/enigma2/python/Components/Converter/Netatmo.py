#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2013
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Components.Converter.Converter import Converter
from Plugins.Extensions.Netatmo.NetatmoCore import NetatmoUnit, Sensor
from Plugins.Extensions.Netatmo import _
from Components.Converter.Poll import Poll

TRANSLATE = "$"

class Netatmo(Poll, Converter, object):
	def __init__(self, type):
		Poll.__init__(self)
		Converter.__init__(self, type)
		self.type = type
		if not type.startswith(TRANSLATE):
			self.poll_enabled = True
	
	def getTranslate(self):
		if self.type.startswith(TRANSLATE):
			if self.type[-1] == ":":
				return _(self.type[len(TRANSLATE):-1]) + ":"
			return _(self.type[len(TRANSLATE):])
		return "N/A"
	
	def getText(self):
		# print "Converter/Netatmo.getText()", self.type
		try:
			from Plugins.Extensions.Netatmo.Netatmo import netatmo
			if len(netatmo.stations) == 0:
				if self.type == "last_refresh" and netatmo.error is not None:
					return netatmo.error
				return self.getTranslate()
			station = netatmo.getStation()
			module = station.getModule()
			if self.type == "station.name":
				return station.name.encode('utf8')
			if self.type == "station.firmware":
				return str(station.firmware)
			if self.type == "indoor.module_name":
				return station.module_name.encode('utf8')
			if self.type == "place.location":
				return str(station.location)
			if self.type == "place.timezone":
				return str(station.timezone)
			if self.type == "place.area":
				return str(station.area)
			if self.type == "indoor.when":
				return str(station.indoor.when)
			if self.type == "indoor.temperature":
				return str(station.indoor.temperature) + netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')
			if self.type == "indoor.humidity":
				return str(station.indoor.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY)
			if self.type == "indoor.pressure":
				return str(station.indoor.pressure) + netatmo.getUint(NetatmoUnit.PRESSURE)
			if self.type == "indoor.noise":
				return str(station.indoor.noise) + netatmo.getUint(NetatmoUnit.NOISE)
			if self.type == "indoor.co2":
				return str(station.indoor.co2) + netatmo.getUint(NetatmoUnit.CO2)
			if self.type == "outdoor.module_name":
				return module.module_name.encode('utf8')
			if self.type == "outdoor.when":
				return str(module.outdoor.when)
			if self.type == "outdoor.temperature":
				return str(module.outdoor.temperature) + netatmo.getUint(NetatmoUnit.TEMPERATURE).encode('utf8')
			if self.type == "outdoor.humidity":
				return str(module.outdoor.humidity) + netatmo.getUint(NetatmoUnit.HUMIDITY)
			if self.type == "outdoor.co2":
				if not module.outdoor.has_co2:
					return ""
				return str(module.outdoor.co2) + netatmo.getUint(NetatmoUnit.CO2)
			if self.type.startswith("outdoor.rainfall"):
				rain_module = station.findRainModule()
				if not rain_module:
					return ""
				what = self.type[17:]
				if what == "name":
					return str(rain_module.module_name)
				s = Sensor.Rain24
				if what == "0": s = Sensor.Rain
				if what == "1": s = Sensor.Rain1
				return str(rain_module.outdoor.getSensor(s)) + netatmo.getUint(NetatmoUnit.MM)
			if self.type == "outdoor.battery":
				return str(module.battery_vp / 1000.0) + " V"
			if self.type == "outdoor.firmware":
				return str(module.firmware)
			if self.type == "last_refresh":
				return netatmo.last_refresh

			# indoor class
			if self.type == "indoor.comfort_class":
				return station.indoor.comf_class
			if self.type == "indoor.temperature_idx":
				return str(station.indoor.idx_temp)
			if self.type == "indoor.humidity_idx":
				return str(station.indoor.idx_humidity)
			if self.type == "indoor.noise_idx":
				return str(station.indoor.idx_noise)
			if self.type == "indoor.co2_idx":
				return str(station.indoor.idx_co2)

			# wifi status
			if self.type == "station.wifi_status":
				return str(station.wifi_status) + " %"
			if self.type == "outdoor.rf_status":
				return str(module.rf_status) + " %"
			
			return self.getTranslate()
		except:
			import sys, traceback
			print "--- [Netatmo] STACK TRACE ---"
			traceback.print_exc(file=sys.stdout)
			print '-----------------------------'
			return "Error"
		
		
	text = property(getText)
