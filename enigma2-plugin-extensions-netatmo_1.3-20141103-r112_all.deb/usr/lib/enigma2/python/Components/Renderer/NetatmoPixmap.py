#!/usr/bin/python
# -*- coding: utf-8 -*- 
#  Netatmo for Dreambox-Enigma2
#
#  Coded by cmikula (c)2014
#  Support: www.i-have-a-dreambox.com
#
#  This plugin is licensed under the Creative Commons 
#  Attribution-NonCommercial-ShareAlike 3.0 Unported 
#  License. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#
#  Alternatively, this plugin may be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.
#
#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially 
#  distributed other than under the conditions noted above.
#
from Tools.Directories import resolveFilename, SCOPE_SKIN_IMAGE, SCOPE_CURRENT_PLUGIN
from os import path
from skin import loadPixmap
from Components.Renderer.Pixmap import Pixmap
from Plugins.Extensions.Netatmo.Netatmo import netatmo

class NetatmoPixmap(Pixmap):
	UNKNOWN = 0
	def __init__(self):
		Pixmap.__init__(self)
		self.__type = self.UNKNOWN
		self.pixmaps = []
	
	def applySkin(self, desktop, screen):
		if self.skinAttributes is not None:
			skin_path_prefix = getattr(screen, "skin_path", path)
			pixmap = None
			attribs = [ ]
			pix_path = None
			for attr in self.skinAttributes:
				if attr[0] == "plugin_pixmaps":
					pix_path = attr[1]
					self.skinAttributes.remove(attr)
					break
			for (attrib, value) in self.skinAttributes:
				if attrib == "pixmaps":
					pixmaps = value.split(',')
					for p in pixmaps:
						if not pix_path:
							self.pixmaps.append(loadPixmap(resolveFilename(SCOPE_SKIN_IMAGE, p, path_prefix=skin_path_prefix), desktop))
						else:
							self.pixmaps.append(loadPixmap(resolveFilename(SCOPE_CURRENT_PLUGIN, path.join("Extensions/Netatmo/", pix_path, p)), desktop))
					if not pixmap:
						if not pix_path:
							pixmap = resolveFilename(SCOPE_SKIN_IMAGE, pixmaps[0], path_prefix=skin_path_prefix)
						else:
							pixmap = resolveFilename(SCOPE_CURRENT_PLUGIN, path.join("Extensions/Netatmo/", pix_path, pixmaps[0]))
				elif attrib == "pixmap":
					if not pix_path:
						pixmap = resolveFilename(SCOPE_SKIN_IMAGE, value, path_prefix=skin_path_prefix)
					else:
						pixmap = resolveFilename(SCOPE_CURRENT_PLUGIN, path.join("Extensions/Netatmo/", pix_path, path.split(value)[1]))
				elif attrib == "pixtype":
					self.__type = value
				else:
					attribs.append((attrib, value))
			if pixmap:
				attribs.append(("pixmap", pixmap))
			self.skinAttributes = attribs
		return Pixmap.applySkin(self, desktop, screen)

	def setPixmapNum(self, x):
		if self.instance:
			if len(self.pixmaps) > x:
				self.instance.setPixmap(self.pixmaps[x])
			else:
				print "setPixmapNum(%d) failed! defined pixmaps:" % (x), self.pixmaps
	
	def onShow(self):
		print "show", self.__type
		Pixmap.onShow(self)
		s = netatmo.getStation()
		if s is None:
			return
		m = s.getModule()
		# rain module
		if self.__type == "rain":
			if s.findRainModule():
				self.show()
			else:
				self.hide()
		# station co2
		elif self.__type == "co2":
			y = float(s.indoor.co2 - 400)
			if s.indoor.co2 < 600:  
				x = y / 15
			else:
				x = y / 16
			# 
			if x >= 100:
				pix_num = 9
			elif x <= 0:
				pix_num = 0
			else:
				pix_num = int(x / 10.0)
			self.setPixmapNum(pix_num)
		# station wifi status
		elif self.__type == "wifi_status":
			x = s.wifi_status
			if x < 55:
				self.setPixmapNum(4)
			elif x < 65:
				self.setPixmapNum(3)
			elif x < 75:
				self.setPixmapNum(2)
			elif x < 85:
				self.setPixmapNum(1)
			else:
				self.setPixmapNum(0)
		# module signal status
		elif self.__type == "rf_status":
			if m is None:
				self.hide()
				return
			x = m.rf_status
			if x < 60:
				self.setPixmapNum(5)
			elif x < 70:
				self.setPixmapNum(4)
			elif x < 80:
				self.setPixmapNum(3)
			elif x < 90:
				self.setPixmapNum(2)
			elif x < 100:
				self.setPixmapNum(1)
			else:
				self.setPixmapNum(0)
		# module signal status
		elif self.__type == "battery_vp":
			if m is None:
				self.hide()
				return
			x = m.battery_vp
			if x > 5500:
				self.setPixmapNum(5)
			elif x > 5000:
				self.setPixmapNum(4)
			elif x > 4500:
				self.setPixmapNum(3)
			elif x > 4000:
				self.setPixmapNum(2)
			elif x > 1:
				self.setPixmapNum(1)
			else:
				self.setPixmapNum(0)

			
